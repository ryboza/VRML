import pymeshlab
from voxel import MeshVoxel 
import CasSurface
#import matplotlib.pyplot as plt
import numpy as np
class Cas:
    def __init__(self):
        self.DomainCollector = []
        self.ms = pymeshlab.MeshSet()        
        self.ms.load_new_mesh("CAS_2_domains.wrl")    
        self.ms.generate_splitting_by_connected_components(delete_source_mesh = True)
        self.ms.get_geometric_measures()
        self.ms.__str__()
        for i  in range(1, self.ms.mesh_number()+1):
            self.ms.set_current_mesh(i)
            #set output object
            surface = CasSurface.CasSurface(self.ms, self.ms.current_mesh())            
            self.DomainCollector.append(surface)
            
def measure_distance(point1, point2):
    return np.sum((point1 - point2)**2)
    #return np.linalg.norm(point1 - point2)

def build_adjacency_matrix(casobject, threshold_distance=0.002):
    threshold_distance = threshold_distance**2
    adjacency_matrix = np.zeros((len(casobject.DomainCollector), len(casobject.DomainCollector)))

    for surface1_idx, surface1 in enumerate(casobject.DomainCollector):
        for surface2_idx, surface2 in enumerate(casobject.DomainCollector):
            if surface1_idx == surface2_idx:
                adjacency_matrix[surface1_idx, surface2_idx] = 1
                continue
            
            surface1_points = surface1.ML_edge_vertex_matrix
            surface2_points = surface2.ML_edge_vertex_matrix
            
            for point1 in surface1_points:
                for point2 in surface2_points:
                    distance = measure_distance(point1, point2)
                    if distance < threshold_distance:
                        adjacency_matrix[surface1_idx, surface2_idx] = 1
                        adjacency_matrix[surface2_idx, surface1_idx] = 1
                        break  # Break loop if at least one point meets the threshold
    
    return adjacency_matrix           


def check_voxel_overlap(voxel1, voxel2):
    """
    Check if two voxels overlap.

    Parameters:
        voxel1: MeshVoxel
            First MeshVoxel object.
        voxel2: MeshVoxel
            Second MeshVoxel object.

    Returns:
        bool
            True if the voxels overlap, False otherwise.
    """
    # Calculate the boundaries of the two voxels
    voxel1_min = voxel1.center - voxel1.dim / 2
    voxel1_max = voxel1.center + voxel1.dim / 2
    voxel2_min = voxel2.center - voxel2.dim / 2
    voxel2_max = voxel2.center + voxel2.dim / 2

    # Calculate the boundaries of the intersection
    intersection_min = np.maximum(voxel1.min_os, voxel2.min_os)
    intersection_max = np.minimum(voxel1.max_os, voxel2.max_os)

    # Calculate the dimensions of the intersection
    intersection_dim = np.maximum(0, intersection_max - intersection_min)

    # Calculate the volume of the intersection
    intersection_volume = np.prod(intersection_dim)

    # If the volume of the intersection is greater than 0, the voxels overlap
    return intersection_volume > 0



def build_adjacency_matrix_voxel(casobject):
    """
    Build an adjacency matrix based on voxel overlapping.

    Parameters:
        voxels: list
            List of MeshVoxel objects.
        threshold_overlap: float, optional (default=0.002)
            Threshold for voxel overlapping.

    Returns:
        np.ndarray
            Adjacency matrix indicating the adjacency between voxels.
    """
    num_voxels = len(casobject.DomainCollector)
    adjacency_matrix = np.zeros((len(casobject.DomainCollector), len(casobject.DomainCollector)))

    for voxel1_idx, surface1 in enumerate(casobject.DomainCollector):
        for voxel2_idx, surface2 in enumerate(casobject.DomainCollector):
            if voxel1_idx == voxel2_idx:
                adjacency_matrix[voxel1_idx, voxel2_idx] = 1
                continue        

            voxel1 = surface1.voxel
            voxel2 = surface2.voxel  
                 
            if check_voxel_overlap(voxel1, voxel2):
                adjacency_matrix[voxel1_idx, voxel2_idx] = 1
                adjacency_matrix[voxel2_idx, voxel1_idx] = 1       
            
    return adjacency_matrix                
        


            
casobject =Cas()
#adjacency_matrix = build_adjacency_matrix_voxel(casobject)
adjacency_matrix = build_adjacency_matrix(casobject)

print("Adjacency Matrix:")
print(adjacency_matrix)


def dfs(adjacency_matrix, visited, current_vertex, current_group):
    visited[current_vertex] = True
    current_group.append(current_vertex)

    for neighbor, connected in enumerate(adjacency_matrix[current_vertex]):
        if connected == 1 and not visited[neighbor]:
            dfs(adjacency_matrix, visited, neighbor, current_group)

def extract_non_adjacent_groups(adjacency_matrix):
    num_surfaces = len(adjacency_matrix)
    visited = [False] * num_surfaces
    non_adjacent_groups = []

    for vertex in range(num_surfaces):
        if not visited[vertex]:
            current_group = []
            dfs(adjacency_matrix, visited, vertex, current_group)
            non_adjacent_groups.append(current_group)

    return non_adjacent_groups




output = extract_non_adjacent_groups(adjacency_matrix)
pass





