import numpy as np
import pymeshlab
import voxel
class CasSurface:
    def __init__(self, parent_mesh_set : pymeshlab.MeshSet, mesh: pymeshlab.Mesh):
        """
        Initialize the Cas Surface .
        Parameters:
        
        """
        self.PML_parent_mesh_set = parent_mesh_set
        self.PML_mesh = mesh
        self.PML_bounding_box = None

        #set boundary polyline
        self.PML_parent_mesh_set.set_selection_all()
        self.PML_parent_mesh_set.generate_polyline_from_selection_perimeter()
        self.PML_parent_mesh_set.set_selection_none()
        self.ML_edge_matrix = self.PML_parent_mesh_set.current_mesh().edge_matrix() #new mesh was generated and it is always a ms.current mesh
        self.ML_edge_vertex_matrix = self.PML_parent_mesh_set.current_mesh().vertex_matrix() #new mesh was generated and it is always a ms.current mesh
        
        #set bounding box
        self.PML_mesh.update_bounding_box()
        self.PML_bounding_box = self.PML_mesh.bounding_box()

        #set voxel
        self.voxel=voxel.MeshVoxel(self.PML_bounding_box, oversize=0.0000002)


    
    def __repr__(self):
        """
        Return a string representation of the voxel.
        """
        return f"Voxel(vertices={self.vertices})"
